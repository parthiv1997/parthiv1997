import React from 'react';
import "../Style/Mymoves.css";

interface WithOutCategoriesProps {
  fetchData: any;
}

const WithOutCategories: React.FC<WithOutCategoriesProps> = ({fetchData}) => {

  return (
    <div className='acdive' style={{width:'25%'}}>                  
       <div className='container_div1'>
       {fetchData.itemsList.all !== null && fetchData.itemsList.all !== undefined ? fetchData.itemsList.all.filter(item => item !== null).filter(o=>parseInt(o.qty) > 0).map((n, m) => (
      <div className='sub_container3'>
        <span className='sub_container223'>
          <span>{n.display_name}</span>
          <span>{parseInt(n.qty)}</span>
        </span>
        <span className='bold'>{n !== null && n !== undefined?n.size !== null && n.size !== undefined?n.size.defaultSelect:n.type !== null && n.type !== undefined?n.type.default_type[0]:"" :""}</span>
      </div>     )):<></>} 
    </div>      
  </div>
  );
}

export default WithOutCategories;
