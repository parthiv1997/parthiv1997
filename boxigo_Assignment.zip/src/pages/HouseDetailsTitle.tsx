import React from 'react';
import "../Style/Mymoves.css";

const HouseDetailsTitle: React.FC = () => {

  return (
    <div className='container_divlast'>
    <span className='titleText'>House Details</span>
    <div className='sub_container22'>
      <button className='button3 textDefaultSize'> Edit House details</button>
    </div>
  </div>
  );
}

export default HouseDetailsTitle;
